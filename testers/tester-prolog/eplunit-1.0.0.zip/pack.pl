name(eplunit).
title('Extended PlUnit').
version('1.0.0').
home('https://github.com/thunkk/swipl-tester').